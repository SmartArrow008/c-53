import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';
 
 class Greenbutton extends Component{
   render(){
     return <Button title = "Know more" color = "green"/>
     
   }
 }

export default class App extends Component {
  render() {
    return (
      
      <View> 
       <Greenbutton/>
       <br></br>
       <Text>Introduction: This web page, talks about the computer programming language 'React-native'.
       To know about other programming languages, click on the 'Know More' button above.  Lets Get Started!!
       </Text>
       <br></br>
       <br></br>
       <Text> 'React- Native' is a computer programming language, used to create apps. It uses java script and html
       both, which makes it like a hybrid. Below are some of the major functions and codes used in the language, with their respective roles and uses.
   
 </Text>
      <br></br>
       <Text>  1) import- Used to put in a class in a programe </Text>
        <br></br>
        <Text>  2) Component- Are the main features of the functions and codes, which include Button, Text, View etc. </Text>
        <br></br>
        <Text>  3) extends- Used to link one class or component to another </Text>
        <br></br>
        <Text>  4) render & return- Used to refer to a part of programe/code, and then implement it towards the solution. </Text>
         <br></br>
         <Text>  5) export default class- Used as the function draw in programming language java script, mainly to start the programme. </Text>
<br></br>
     <Text>  6) View- Used to link in multiple components.</Text>
     <br></br>
     <Text> Important Note! The capitalization needs to be considered while writing codes throughout. There should atleast be 1 render, return, and export default class. In order to have more tahn 2 componets under same class, you have to use view. Any queries, please revert back to my link in the know more section! </Text>
      </View>
     
    );
  }
}
